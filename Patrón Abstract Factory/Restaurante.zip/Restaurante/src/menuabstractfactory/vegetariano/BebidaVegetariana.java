package menuabstractfactory.vegetariano;

import menuabstractfactory.interfaces.Bebida;

public class BebidaVegetariana implements Bebida {
    public String descripcion() { return "Jugo de zanahoria."; }
}
