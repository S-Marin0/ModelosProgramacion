package menuabstractfactory.vegetariano;

import menuabstractfactory.interfaces.Postre;

public class PostreVegetariano implements Postre {
    public String descripcion() { return "Tarta de manzana sin azúcar."; }
}
