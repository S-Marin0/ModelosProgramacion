package menuabstractfactory.vegetariano;

import menuabstractfactory.interfaces.PlatoPrincipal;

public class PlatoPrincipalVegetariano implements PlatoPrincipal {
    public String descripcion() { return "Lasaña de espinacas."; }
}
