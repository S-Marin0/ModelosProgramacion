package menuabstractfactory.vegetariano;

import menuabstractfactory.interfaces.Entrada;

public class EntradaVegetariana implements Entrada {
    public String descripcion() { return "Ensalada de quinoa."; }
}
