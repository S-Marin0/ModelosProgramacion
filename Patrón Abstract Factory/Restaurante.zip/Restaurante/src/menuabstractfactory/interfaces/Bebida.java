package menuabstractfactory.interfaces;

public interface Bebida {
    String descripcion();
}
