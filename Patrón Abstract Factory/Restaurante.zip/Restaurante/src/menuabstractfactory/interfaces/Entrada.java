package menuabstractfactory.interfaces;

// Interfaces de los productos
public interface Entrada {
    String descripcion();
}
